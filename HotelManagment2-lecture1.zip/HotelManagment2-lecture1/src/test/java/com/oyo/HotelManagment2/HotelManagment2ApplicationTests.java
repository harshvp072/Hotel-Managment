package com.oyo.HotelManagment2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HotelManagment2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
