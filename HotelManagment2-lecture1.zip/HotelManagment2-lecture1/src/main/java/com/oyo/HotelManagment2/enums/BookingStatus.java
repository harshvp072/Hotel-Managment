package com.oyo.HotelManagment2.enums;

public enum BookingStatus {
}
