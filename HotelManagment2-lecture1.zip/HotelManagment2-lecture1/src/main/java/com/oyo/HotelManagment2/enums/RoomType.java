package com.oyo.HotelManagment2.enums;

public enum RoomType {

    CLASSIC, //0
    DELUXE,
    KING,
    QUEEN //3

}
