package com.oyo.HotelManagment2.dto.request;

public class BookingResponseDto {
}
