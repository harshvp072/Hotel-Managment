package com.oyo.HotelManagment2.interfaces;

import com.oyo.HotelManagment2.dto.NotificationDataDto;

public interface NotificationService {

    void sendNotification(NotificationDataDto notificationDataDto);
}

