package com.oyo.HotelManagment2.Exception;

public class HotelNotFoundException extends Exception{


    public HotelNotFoundException(String message){
        super(message);
    }
}
